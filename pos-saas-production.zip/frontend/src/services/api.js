
export async function callAction(name, data) {
  const res = await fetch("http://localhost:5001/" + name, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(data)
  });

  return res.json();
}
