
# POS SaaS (Production Version)

## Features
- Multi-store SaaS POS
- Firebase backend
- Auth system (basic scaffold)
- Offline-ready architecture
- Subscription-ready structure

## Run Frontend
cd frontend
npm install
npm run dev

## Run Backend
firebase emulators:start

## Deploy
firebase deploy
vercel deploy

## Next upgrades
- Stripe / JazzCash billing
- Real inventory UI
- Analytics dashboard
