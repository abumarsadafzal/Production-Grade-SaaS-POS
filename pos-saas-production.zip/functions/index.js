
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

exports.createSale = functions.https.onRequest(async (req, res) => {
  const { store_id, items, payment_method, amount_paid } = req.body;

  let subtotal = 0;
  items.forEach(i => subtotal += (i.price || 0) * (i.quantity || 1));

  const gst = subtotal * 0.16;
  const total = subtotal + gst;

  const doc = await db.collection("sales").add({
    store_id,
    items,
    subtotal,
    gst,
    total,
    payment_method,
    amount_paid,
    created_at: new Date()
  });

  res.json({ sale_id: doc.id, total });
});

exports.getProductByBarcode = functions.https.onRequest(async (req, res) => {
  res.json({ name: "Demo Product", price: 100 });
});
