
import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { callAction } from "../services/api";

export default function POS() {
  const { user } = useContext(AuthContext);
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  const checkout = async () => {
    const res = await callAction("createSale", {
      store_id: user.store_id,
      items: cart,
      payment_method: "cash",
      amount_paid: total
    });

    alert("Sale completed: " + res.sale_id);
    setCart([]);
    setTotal(0);
  };

  return (
    <div style={{display:"flex",height:"100vh",fontFamily:"sans-serif"}}>

      <div style={{flex:2,padding:20}}>
        <h2>POS System</h2>
        <p>Store: {user.store_id}</p>
      </div>

      <div style={{flex:1,background:"#f4f4f4",padding:20}}>
        <h1 style={{fontSize:40}}>Rs. {total}</h1>

        <button onClick={checkout} style={{padding:10,marginTop:20}}>
          Checkout
        </button>
      </div>

    </div>
  );
}
