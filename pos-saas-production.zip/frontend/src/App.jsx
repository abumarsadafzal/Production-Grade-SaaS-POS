
import POS from "./pages/POS";
import { AuthProvider } from "./context/AuthContext";

export default function App() {
  return (
    <AuthProvider>
      <POS />
    </AuthProvider>
  );
}
